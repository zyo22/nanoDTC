from nanodemo.dataobject import DataObject
from nanodemo.processingobject import ProcessingObject
